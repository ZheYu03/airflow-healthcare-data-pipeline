"""Supabase client for upserting clinic data."""

import os
import hashlib
import logging
from datetime import datetime, timezone
from typing import List, Dict, Any

from supabase import create_client, Client

logger = logging.getLogger(__name__)


class SupabaseClient:
    """Client for upserting clinic data to Supabase."""

    TABLE_NAME = "Clinic Facilities"

    def __init__(self, url: str = None, key: str = None):
        """
        Initialize the Supabase client.

        Args:
            url: Supabase project URL. If None, uses SUPABASE_URL env var.
            key: Supabase service role key. If None, uses SUPABASE_SERVICE_ROLE_KEY env var.
        """
        if url is None:
            url = os.environ.get("SUPABASE_URL")
        if key is None:
            key = os.environ.get("SUPABASE_SERVICE_ROLE_KEY")

        if not url or not key:
            raise ValueError(
                "url and key must be provided or "
                "SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY env vars must be set"
            )

        self.client: Client = create_client(url, key)

    @staticmethod
    def generate_deterministic_id(name: str, address: str) -> str:
        """
        Generate a deterministic UUID-like ID from name and address.

        This ensures the same clinic always gets the same ID for upsert.

        Args:
            name: Clinic name.
            address: Clinic address.

        Returns:
            UUID string derived from the hash.
        """
        # Create a deterministic hash
        content = f"{name.lower().strip()}|{address.lower().strip()}"
        hash_bytes = hashlib.sha256(content.encode()).digest()

        # Format as UUID (8-4-4-4-12)
        hex_str = hash_bytes.hex()[:32]
        uuid_str = f"{hex_str[:8]}-{hex_str[8:12]}-{hex_str[12:16]}-{hex_str[16:20]}-{hex_str[20:32]}"

        return uuid_str

    def transform_for_insert(self, clinic: Dict[str, Any]) -> Dict[str, Any]:
        """
        Transform enriched clinic data to match Supabase table schema.

        Args:
            clinic: Enriched clinic dict from the pipeline.

        Returns:
            Dict matching the Supabase table schema.
        """
        name = clinic.get("name", "")
        address = clinic.get("address", "")

        # Generate deterministic ID for upsert
        clinic_id = self.generate_deterministic_id(name, address)

        # Check for 24 hours in name
        is_24_hours = "24 JAM" in name.upper() or "24JAM" in name.upper()

        now = datetime.now(timezone.utc).isoformat()

        return {
            "id": clinic_id,
            "updated_at": now,
            "name": name,
            "facility_type": clinic.get("facility_type", ""),
            "address": address or None,
            "city": clinic.get("city") or None,
            "state": clinic.get("state") or None,
            "postcode": clinic.get("postcode") or None,
            "latitude": clinic.get("latitude"),
            "longitude": clinic.get("longitude"),
            "phone": clinic.get("phone"),
            "email": None,  # Not available in source data
            "website": clinic.get("website"),
            "operating_hours": clinic.get("operating_hours"),
            "services": None,  # Not available in source data
            "specialties": None,  # Not available in source data
            "accepted_insurance": None,  # Not available in source data
            "is_24_hours": is_24_hours,
            "has_emergency": None,  # Not available in source data
            "is_government": False,  # These are private clinics
            "google_place_id": clinic.get("google_place_id"),
            "google_rating": clinic.get("google_rating"),
            "google_reviews_count": clinic.get("google_reviews_count"),
            "is_active": True,
        }

    def upsert_clinics(self, clinics: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Upsert clinic records to Supabase.

        Args:
            clinics: List of enriched clinic dicts.

        Returns:
            Dict with upsert statistics.
        """
        if not clinics:
            logger.warning("No clinics to upsert")
            return {"inserted": 0, "updated": 0, "errors": 0}

        # Transform all clinics
        records = [self.transform_for_insert(c) for c in clinics]

        # Deduplicate by id (keep first occurrence)
        seen_ids = set()
        unique_records = []
        for record in records:
            if record["id"] not in seen_ids:
                seen_ids.add(record["id"])
                unique_records.append(record)
            else:
                logger.debug(f"Skipping duplicate: {record['name']}")

        records = unique_records
        logger.info(f"Upserting {len(records)} unique clinic records to Supabase (removed {len(clinics) - len(records)} duplicates)")

        # Batch upsert to avoid payload size limits
        BATCH_SIZE = 500
        total_success = 0
        total_errors = 0

        for i in range(0, len(records), BATCH_SIZE):
            batch = records[i : i + BATCH_SIZE]
            batch_num = i // BATCH_SIZE + 1
            total_batches = (len(records) + BATCH_SIZE - 1) // BATCH_SIZE

            try:
                logger.info(f"Upserting batch {batch_num}/{total_batches} ({len(batch)} records)")
                response = (
                    self.client.table(self.TABLE_NAME)
                    .upsert(batch, on_conflict="id")
                    .execute()
                )
                batch_success = len(response.data) if response.data else 0
                total_success += batch_success

            except Exception as e:
                logger.error(f"Batch {batch_num} failed: {e}")
                total_errors += len(batch)

        logger.info(f"Upsert complete: {total_success} success, {total_errors} errors")

        return {
            "processed": len(records),
            "success": total_success,
            "errors": total_errors,
        }

    def upsert_single(self, clinic: Dict[str, Any]) -> bool:
        """
        Upsert a single clinic record.

        Args:
            clinic: Enriched clinic dict.

        Returns:
            True if successful, False otherwise.
        """
        try:
            record = self.transform_for_insert(clinic)
            self.client.table(self.TABLE_NAME).upsert(
                record, on_conflict="id"
            ).execute()
            return True
        except Exception as e:
            logger.error(f"Failed to upsert clinic {clinic.get('name')}: {e}")
            return False

    def get_unenriched_clinics(self, limit: int = 50) -> List[Dict[str, Any]]:
        """
        Get clinics that haven't been enriched yet (latitude IS NULL).

        Args:
            limit: Maximum number of clinics to return.

        Returns:
            List of clinic dicts with basic info.
        """
        try:
            response = (
                self.client.table(self.TABLE_NAME)
                .select("id, name, address, city, state, postcode, facility_type")
                .is_("latitude", "null")
                .eq("is_active", True)
                .limit(limit)
                .execute()
            )
            clinics = response.data if response.data else []
            logger.info(f"Found {len(clinics)} unenriched clinics")
            return clinics
        except Exception as e:
            logger.error(f"Failed to get unenriched clinics: {e}")
            return []

    def get_unenriched_count(self) -> int:
        """
        Get count of clinics that haven't been enriched yet.

        Returns:
            Count of unenriched clinics.
        """
        try:
            response = (
                self.client.table(self.TABLE_NAME)
                .select("id", count="exact")
                .is_("latitude", "null")
                .eq("is_active", True)
                .execute()
            )
            return response.count if response.count else 0
        except Exception as e:
            logger.error(f"Failed to get unenriched count: {e}")
            return 0

    def update_enrichment(self, clinic_id: str, enrichment_data: Dict[str, Any]) -> bool:
        """
        Update a clinic with enrichment data from scraping.

        Args:
            clinic_id: The clinic's UUID.
            enrichment_data: Dict with enrichment fields (latitude, longitude, phone, etc.)

        Returns:
            True if successful, False otherwise.
        """
        try:
            now = datetime.now(timezone.utc).isoformat()

            update_data = {
                "updated_at": now,
                "latitude": enrichment_data.get("latitude"),
                "longitude": enrichment_data.get("longitude"),
                "phone": enrichment_data.get("phone"),
                "website": enrichment_data.get("website"),
                "operating_hours": enrichment_data.get("operating_hours"),
                "google_place_id": enrichment_data.get("google_place_id"),
                "google_rating": enrichment_data.get("google_rating"),
                "google_reviews_count": enrichment_data.get("google_reviews_count"),
            }

            # Add services and specialties if available
            if enrichment_data.get("services"):
                update_data["services"] = enrichment_data["services"]
            if enrichment_data.get("specialties"):
                update_data["specialties"] = enrichment_data["specialties"]

            # Remove None values to avoid overwriting existing data with nulls
            # But keep latitude/longitude even if None (to mark as "attempted")
            update_data = {
                k: v for k, v in update_data.items()
                if v is not None or k in ("latitude", "longitude")
            }

            self.client.table(self.TABLE_NAME).update(update_data).eq("id", clinic_id).execute()
            logger.debug(f"Updated enrichment for clinic {clinic_id}")
            return True

        except Exception as e:
            logger.error(f"Failed to update enrichment for {clinic_id}: {e}")
            return False

    def mark_enrichment_failed(self, clinic_id: str) -> bool:
        """
        Mark a clinic as having failed enrichment (set latitude to 0 as marker).

        This prevents re-attempting failed clinics immediately.

        Args:
            clinic_id: The clinic's UUID.

        Returns:
            True if successful, False otherwise.
        """
        try:
            now = datetime.now(timezone.utc).isoformat()
            self.client.table(self.TABLE_NAME).update({
                "updated_at": now,
                "latitude": 0.0,  # Marker for "attempted but failed"
                "longitude": 0.0,
            }).eq("id", clinic_id).execute()
            return True
        except Exception as e:
            logger.error(f"Failed to mark enrichment failed for {clinic_id}: {e}")
            return False

