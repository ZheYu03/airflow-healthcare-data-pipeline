"""Google Maps scraper using Playwright for clinic enrichment."""

import asyncio
import random
import re
import logging
from typing import Dict, Any, Optional

from playwright.async_api import async_playwright, Page, Browser

logger = logging.getLogger(__name__)

# User agents to rotate
USER_AGENTS = [
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
]


class GoogleMapsScraper:
    """Scraper for extracting clinic information from Google Maps."""

    def __init__(self, headless: bool = True):
        """
        Initialize the scraper.

        Args:
            headless: Run browser in headless mode (default True).
        """
        self.headless = headless
        self._browser: Optional[Browser] = None
        self._playwright = None

    async def __aenter__(self):
        """Async context manager entry."""
        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(
            headless=self.headless,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
                "--no-sandbox",
            ],
        )
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()

    async def _random_delay(self, min_sec: float = 1.0, max_sec: float = 3.0):
        """Add random delay to simulate human behavior."""
        delay = random.uniform(min_sec, max_sec)
        await asyncio.sleep(delay)

    async def _get_text(self, page: Page, selector: str) -> Optional[str]:
        """Safely get text from an element."""
        try:
            el = await page.query_selector(selector)
            if el:
                text = await el.inner_text()
                return text.strip() if text else None
        except Exception:
            pass
        return None

    async def _get_attribute(self, page: Page, selector: str, attr: str) -> Optional[str]:
        """Safely get attribute from an element."""
        try:
            el = await page.query_selector(selector)
            if el:
                return await el.get_attribute(attr)
        except Exception:
            pass
        return None

    def _parse_coordinates_from_url(self, url: str) -> tuple[Optional[float], Optional[float]]:
        """Extract latitude and longitude from Google Maps URL."""
        # Pattern: @lat,lng,zoom or !3dlat!4dlng
        patterns = [
            r"@(-?\d+\.?\d*),(-?\d+\.?\d*)",  # @lat,lng format
            r"!3d(-?\d+\.?\d*)!4d(-?\d+\.?\d*)",  # !3dlat!4dlng format
        ]
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                try:
                    lat = float(match.group(1))
                    lng = float(match.group(2))
                    # Validate reasonable lat/lng ranges
                    if -90 <= lat <= 90 and -180 <= lng <= 180:
                        return lat, lng
                except (ValueError, IndexError):
                    pass
        return None, None

    def _parse_place_id_from_url(self, url: str) -> Optional[str]:
        """Extract place ID from Google Maps URL."""
        # Pattern: /place/.../.../data=...!1s0x...
        match = re.search(r"!1s(0x[a-f0-9]+:[a-f0-9]+)", url)
        if match:
            return match.group(1)
        # Alternative: ChIJ format
        match = re.search(r"(ChIJ[a-zA-Z0-9_-]+)", url)
        if match:
            return match.group(1)
        return None

    def _parse_rating(self, text: Optional[str]) -> Optional[float]:
        """Parse rating from text like '4.9'."""
        if not text:
            return None
        match = re.search(r"(\d+\.?\d*)", text)
        if match:
            try:
                return float(match.group(1))
            except ValueError:
                pass
        return None

    def _parse_review_count(self, text: Optional[str]) -> Optional[int]:
        """Parse review count from text like '(287)' or '287 reviews'."""
        if not text:
            return None
        # Remove commas and find numbers
        text = text.replace(",", "").replace(".", "")
        match = re.search(r"(\d+)", text)
        if match:
            try:
                return int(match.group(1))
            except ValueError:
                pass
        return None

    async def _parse_operating_hours(self, page: Page) -> Optional[Dict[str, Any]]:
        """Extract operating hours from the info panel."""
        try:
            # Try to find and click the hours expansion button
            hours_button = await page.query_selector('button[data-item-id="oh"]')
            if hours_button:
                await hours_button.click()
                await self._random_delay(0.5, 1.0)

            # Look for hours table/list
            hours_elements = await page.query_selector_all('table.eK4R0e tr, div.OqCZI')
            if hours_elements:
                hours_data = {"weekday_text": [], "periods": []}
                for el in hours_elements:
                    text = await el.inner_text()
                    if text:
                        hours_data["weekday_text"].append(text.strip())
                return hours_data if hours_data["weekday_text"] else None
        except Exception as e:
            logger.debug(f"Failed to parse hours: {e}")
        return None

    async def _extract_services_specialties(self, page: Page) -> tuple[list, list]:
        """Extract services and specialties from the About section or category."""
        services = []
        specialties = []

        try:
            # Try to get the category/type (e.g., "Fertility clinic")
            category = await self._get_text(page, 'button[jsaction*="category"]')
            if category:
                specialties.append(category)

            # Try About section if available
            about_button = await page.query_selector('button[aria-label*="About"]')
            if about_button:
                await about_button.click()
                await self._random_delay(0.5, 1.0)

                # Look for service items
                service_els = await page.query_selector_all('div[data-attrid] span')
                for el in service_els:
                    text = await el.inner_text()
                    if text and len(text) < 100:
                        services.append(text.strip())

        except Exception as e:
            logger.debug(f"Failed to extract services: {e}")

        return services[:10], specialties[:5]  # Limit to reasonable counts

    async def scrape_clinic(self, name: str, address: str, city: str, state: str) -> Dict[str, Any]:
        """
        Scrape a clinic's information from Google Maps.

        Args:
            name: Clinic name.
            address: Clinic address.
            city: City name.
            state: State name.

        Returns:
            Dict with enriched clinic data.
        """
        result = {
            "latitude": None,
            "longitude": None,
            "phone": None,
            "website": None,
            "operating_hours": None,
            "services": None,
            "specialties": None,
            "google_place_id": None,
            "google_rating": None,
            "google_reviews_count": None,
            "scrape_success": False,
            "scrape_error": None,
        }

        if not self._browser:
            result["scrape_error"] = "Browser not initialized"
            return result

        # Build search query
        query_parts = [name]
        if address:
            query_parts.append(address)
        if city:
            query_parts.append(city)
        if state:
            query_parts.append(state)
        query_parts.append("Malaysia")
        query = ", ".join(filter(None, query_parts))

        page = None
        try:
            # Create new page with random user agent
            context = await self._browser.new_context(
                user_agent=random.choice(USER_AGENTS),
                viewport={"width": 1280, "height": 800},
                locale="en-US",
            )
            page = await context.new_page()

            # Navigate to Google Maps
            logger.info(f"Searching for: {name}")
            await page.goto("https://www.google.com/maps", wait_until="domcontentloaded")
            await self._random_delay(1.5, 2.5)

            # Fill search box and search
            search_box = await page.wait_for_selector('input#searchboxinput', timeout=10000)
            await search_box.fill(query)
            await self._random_delay(0.3, 0.7)
            await page.keyboard.press("Enter")
            await self._random_delay(3.0, 5.0)

            # Check for CAPTCHA or unusual traffic page
            page_content = await page.content()
            if "unusual traffic" in page_content.lower() or "captcha" in page_content.lower():
                result["scrape_error"] = "CAPTCHA detected"
                logger.warning("CAPTCHA detected - need to pause scraping")
                return result

            # Try to click the first result if we're on a list view
            try:
                first_result = await page.query_selector('div[role="article"]')
                if first_result:
                    await first_result.click()
                    await self._random_delay(2.0, 3.0)
            except Exception:
                pass  # May already be on detail view

            # Wait for info panel to load
            await self._random_delay(2.0, 3.0)

            # Get current URL for coordinates and place ID
            current_url = page.url
            lat, lng = self._parse_coordinates_from_url(current_url)
            result["latitude"] = lat
            result["longitude"] = lng
            result["google_place_id"] = self._parse_place_id_from_url(current_url)

            # Extract name/title to verify we found the right place
            found_name = await self._get_text(page, "h1.DUwDvf, h1.fontHeadlineLarge")
            if found_name:
                logger.debug(f"Found place: {found_name}")

            # Extract rating
            rating_text = await self._get_text(page, "span.F7nice span, div.F7nice span")
            result["google_rating"] = self._parse_rating(rating_text)

            # Extract review count
            reviews_text = await self._get_text(page, 'button[jsaction*="reviews"] span, span.F7nice + span')
            if not reviews_text:
                # Try alternative selector
                reviews_text = await self._get_text(page, 'button.hh2c6, span.UY7F9')
            result["google_reviews_count"] = self._parse_review_count(reviews_text)

            # Extract phone
            phone_el = await page.query_selector('button[data-item-id^="phone:tel"]')
            if phone_el:
                phone_text = await phone_el.get_attribute("data-item-id")
                if phone_text and phone_text.startswith("phone:tel:"):
                    result["phone"] = phone_text.replace("phone:tel:", "")
            if not result["phone"]:
                # Try alternative
                phone_text = await self._get_text(page, 'button[data-tooltip="Copy phone number"]')
                if phone_text:
                    result["phone"] = phone_text

            # Extract website
            website_el = await page.query_selector('a[data-item-id^="authority"]')
            if website_el:
                result["website"] = await website_el.get_attribute("href")

            # Extract operating hours
            result["operating_hours"] = await self._parse_operating_hours(page)

            # Extract services and specialties
            services, specialties = await self._extract_services_specialties(page)
            result["services"] = services if services else None
            result["specialties"] = specialties if specialties else None

            result["scrape_success"] = True
            logger.info(f"Successfully scraped: {name} (rating: {result['google_rating']}, coords: {lat},{lng})")

        except Exception as e:
            result["scrape_error"] = str(e)
            logger.error(f"Scrape failed for {name}: {e}")

        finally:
            if page:
                try:
                    await page.close()
                except Exception:
                    pass

        return result


async def scrape_single_clinic(
    name: str,
    address: str,
    city: str,
    state: str,
    headless: bool = True
) -> Dict[str, Any]:
    """
    Convenience function to scrape a single clinic.

    Args:
        name: Clinic name.
        address: Clinic address.
        city: City name.
        state: State name.
        headless: Run browser in headless mode.

    Returns:
        Dict with enriched clinic data.
    """
    async with GoogleMapsScraper(headless=headless) as scraper:
        return await scraper.scrape_clinic(name, address, city, state)


def scrape_clinic_sync(
    name: str,
    address: str,
    city: str,
    state: str,
    headless: bool = True
) -> Dict[str, Any]:
    """
    Synchronous wrapper for scraping a single clinic.

    Args:
        name: Clinic name.
        address: Clinic address.
        city: City name.
        state: State name.
        headless: Run browser in headless mode.

    Returns:
        Dict with enriched clinic data.
    """
    return asyncio.run(scrape_single_clinic(name, address, city, state, headless))

