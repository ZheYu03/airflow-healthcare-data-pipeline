"""
Clinic Enrichment DAG

This DAG runs hourly to enrich clinic data by scraping Google Maps.
It processes ~50 clinics per hour to avoid detection and rate limiting.

Schedule: Every hour
"""

import asyncio
import random
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Any

from airflow import DAG
from airflow.operators.python import PythonOperator, ShortCircuitOperator
from airflow.models import Variable

from helpers.supabase_client import SupabaseClient
from helpers.maps_scraper import GoogleMapsScraper

logger = logging.getLogger(__name__)

# Configuration
BATCH_SIZE = int(Variable.get("ENRICHMENT_BATCH_SIZE", default_var="50"))
MIN_DELAY_SECONDS = int(Variable.get("ENRICHMENT_MIN_DELAY", default_var="8"))
MAX_DELAY_SECONDS = int(Variable.get("ENRICHMENT_MAX_DELAY", default_var="15"))
HEADLESS_MODE = Variable.get("ENRICHMENT_HEADLESS", default_var="true").lower() == "true"

# Default args for the DAG
default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=10),
}


def check_unenriched_clinics(**context) -> bool:
    """
    Check if there are unenriched clinics to process.
    Returns True if there are clinics to process, False to skip.
    """
    supabase = SupabaseClient()
    count = supabase.get_unenriched_count()
    logger.info(f"Found {count} unenriched clinics remaining")

    if count == 0:
        logger.info("No unenriched clinics - skipping this run")
        return False

    return True


def get_clinics_to_enrich(**context) -> List[Dict[str, Any]]:
    """
    Fetch a batch of unenriched clinics from Supabase.
    """
    supabase = SupabaseClient()
    clinics = supabase.get_unenriched_clinics(limit=BATCH_SIZE)

    logger.info(f"Retrieved {len(clinics)} clinics for enrichment")

    # Push to XCom
    context["ti"].xcom_push(key="clinics_to_enrich", value=clinics)

    return clinics


async def _scrape_batch(clinics: List[Dict[str, Any]], headless: bool) -> List[Dict[str, Any]]:
    """
    Async function to scrape a batch of clinics.
    """
    results = []

    async with GoogleMapsScraper(headless=headless) as scraper:
        for i, clinic in enumerate(clinics):
            clinic_id = clinic.get("id")
            name = clinic.get("name", "")
            address = clinic.get("address", "")
            city = clinic.get("city", "")
            state = clinic.get("state", "")

            logger.info(f"Scraping clinic {i + 1}/{len(clinics)}: {name}")

            try:
                # Scrape the clinic
                enrichment = await scraper.scrape_clinic(name, address, city, state)
                enrichment["clinic_id"] = clinic_id
                enrichment["name"] = name
                results.append(enrichment)

                # Random delay between requests
                if i < len(clinics) - 1:  # No delay after last item
                    delay = random.uniform(MIN_DELAY_SECONDS, MAX_DELAY_SECONDS)
                    logger.debug(f"Waiting {delay:.1f}s before next request")
                    await asyncio.sleep(delay)

            except Exception as e:
                logger.error(f"Failed to scrape {name}: {e}")
                results.append({
                    "clinic_id": clinic_id,
                    "name": name,
                    "scrape_success": False,
                    "scrape_error": str(e),
                })

    return results


def scrape_clinics(**context) -> Dict[str, Any]:
    """
    Scrape Google Maps for clinic information.
    """
    ti = context["ti"]
    clinics = ti.xcom_pull(key="clinics_to_enrich", task_ids="get_clinics_to_enrich")

    if not clinics:
        logger.warning("No clinics to scrape")
        return {"total": 0, "success": 0, "failed": 0}

    logger.info(f"Starting to scrape {len(clinics)} clinics")

    # Run async scraping
    results = asyncio.run(_scrape_batch(clinics, HEADLESS_MODE))

    # Push results to XCom
    ti.xcom_push(key="scrape_results", value=results)

    # Count success/failure
    success_count = sum(1 for r in results if r.get("scrape_success"))
    failed_count = len(results) - success_count

    logger.info(f"Scraping complete: {success_count} success, {failed_count} failed")

    return {
        "total": len(results),
        "success": success_count,
        "failed": failed_count,
    }


def update_supabase(**context) -> Dict[str, Any]:
    """
    Update Supabase with scraped enrichment data.
    """
    ti = context["ti"]
    results = ti.xcom_pull(key="scrape_results", task_ids="scrape_clinics")

    if not results:
        logger.warning("No scrape results to update")
        return {"updated": 0, "failed": 0}

    supabase = SupabaseClient()
    updated = 0
    failed = 0

    for result in results:
        clinic_id = result.get("clinic_id")
        if not clinic_id:
            continue

        if result.get("scrape_success"):
            # Update with enrichment data
            success = supabase.update_enrichment(clinic_id, result)
            if success:
                updated += 1
                logger.debug(f"Updated enrichment for {result.get('name')}")
            else:
                failed += 1
        else:
            # Mark as failed (so we don't retry immediately)
            supabase.mark_enrichment_failed(clinic_id)
            failed += 1
            logger.debug(f"Marked failed for {result.get('name')}: {result.get('scrape_error')}")

    logger.info(f"Supabase update complete: {updated} updated, {failed} failed/skipped")

    # Log remaining count
    remaining = supabase.get_unenriched_count()
    logger.info(f"Remaining unenriched clinics: {remaining}")

    return {
        "updated": updated,
        "failed": failed,
        "remaining": remaining,
    }


# Define the DAG
with DAG(
    dag_id="clinic_enrichment",
    default_args=default_args,
    description="Enrich clinic data by scraping Google Maps hourly",
    schedule_interval="0 * * * *",  # Every hour
    start_date=datetime(2025, 12, 1),
    catchup=False,
    tags=["clinic", "enrichment", "scraping", "google-maps"],
    max_active_runs=1,  # Only one run at a time
) as dag:

    # Task 1: Check if there are clinics to enrich (short-circuit if none)
    check_task = ShortCircuitOperator(
        task_id="check_unenriched",
        python_callable=check_unenriched_clinics,
        provide_context=True,
    )

    # Task 2: Get batch of unenriched clinics
    get_clinics_task = PythonOperator(
        task_id="get_clinics_to_enrich",
        python_callable=get_clinics_to_enrich,
        provide_context=True,
    )

    # Task 3: Scrape Google Maps for each clinic
    scrape_task = PythonOperator(
        task_id="scrape_clinics",
        python_callable=scrape_clinics,
        provide_context=True,
        execution_timeout=timedelta(hours=2),  # Allow up to 2 hours for scraping
    )

    # Task 4: Update Supabase with enrichment data
    update_task = PythonOperator(
        task_id="update_supabase",
        python_callable=update_supabase,
        provide_context=True,
    )

    # Task dependencies
    check_task >> get_clinics_task >> scrape_task >> update_task

