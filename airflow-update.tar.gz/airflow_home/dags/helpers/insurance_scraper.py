"""Insurance plan scraper for Malaysian insurance companies.

Scrapes medical/health insurance plans from:
- AIA Malaysia
- Prudential BSN
- Allianz Malaysia
- Great Eastern
- Etiqa Insurance

Uses Playwright for HTML scraping and pdfplumber for PDF parsing.
"""

import asyncio
import hashlib
import io
import logging
import random
import re
import tempfile
from typing import Any, Dict, List, Optional, Tuple

from playwright.async_api import Browser, Page, async_playwright

logger = logging.getLogger(__name__)

# User agents to rotate
USER_AGENTS = [
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0",
]

# Insurance provider configurations (web scraping only - no hardcoded plans)
PROVIDERS = {
    "AIA": {
        "name": "AIA Malaysia",
        "base_url": "https://www.aia.com.my",
        "products_url": "https://www.aia.com.my/en/our-products/health-protection.html",
        "contact_phone": "1300-88-1318",
        "website": "https://www.aia.com.my",
    },
    "Prudential": {
        "name": "Prudential BSN Takaful",
        "base_url": "https://www.prubsn.com.my",
        "products_url": "https://www.prubsn.com.my/en/our-products/health/",
        "contact_phone": "1300-88-7288",
        "website": "https://www.prubsn.com.my",
    },
    "Allianz": {
        "name": "Allianz Malaysia",
        "base_url": "https://www.allianz.com.my",
        "products_url": "https://www.allianz.com.my/personal/health-protection.html",
        "contact_phone": "1300-22-5542",
        "website": "https://www.allianz.com.my",
    },
    "GreatEastern": {
        "name": "Great Eastern Life",
        "base_url": "https://www.greateasternlife.com",
        "products_url": "https://www.greateasternlife.com/my/en/personal-insurance/health-insurance.html",
        "contact_phone": "1300-13-8338",
        "website": "https://www.greateasternlife.com/my",
    },
    "Etiqa": {
        "name": "Etiqa Insurance",
        "base_url": "https://www.etiqa.com.my",
        "products_url": "https://www.etiqa.com.my/v2/medical-and-health",
        "contact_phone": "1300-13-8888",
        "website": "https://www.etiqa.com.my",
    },
}


def is_valid_plan_name(name: str) -> bool:
    """Check if a string looks like a valid insurance plan name."""
    if not name or len(name) < 4 or len(name) > 80:
        return False
    
    name_lower = name.lower().strip()
    
    # Filter out generic/navigation text
    invalid_patterns = [
        "health protection", "medical protection", "life protection",
        "click", "read more", "learn more", "find out", "explore",
        "contact us", "about us", "about ", "home", "menu", "login", "register",
        "cookie", "privacy", "terms", "copyright", "footer", "header",
        "navigation", "search", "loading", "error", "submit", "subscribe",
        "today", "logo", "provider", "service company", "welcome",
        "vitality", "customer support", "road ranger", "auto assist",
        "cares", " has ", " we ", "support", "assist", "children &",
        "wellness", "how ", "what ", "why ", "when ", "where ",
        # Additional filters for common false positives
        "knowledge hub", "insurance type", "insurance needs", "sign up",
        "sign in", "log in", "get quote", "view more", "view all",
        "download", "brochure", "pdf", "contact", "email", "phone",
        "follow us", "social", "facebook", "twitter", "instagram",
        "linkedin", "youtube", "sdn bhd", "berhad", "holdings",
        "services", "programme", "program", "healthiest", "campaign",
        "news", "article", "blog", "event", "promotion", "offer",
    ]
    
    for pattern in invalid_patterns:
        if pattern in name_lower:
            return False
    
    # Must start with a letter
    if not name[0].isalpha():
        return False
    
    # Should contain some letters (not just symbols/numbers)
    letter_count = sum(1 for c in name if c.isalpha())
    if letter_count < 3:
        return False
    
    # Known good prefixes for insurance products
    good_prefixes = [
        "pru", "aia ", "allianz", "great ", "etiqa", "takaful", "medisafe",
        "supreme", "smart", "a-plus", "a-life", "critical", "hospital",
        "i-medik", "medical ez", "mediplus",
    ]
    
    # Boost confidence for names with known prefixes
    has_good_prefix = any(name_lower.startswith(prefix) for prefix in good_prefixes)
    
    # If short name without good prefix, likely not valid
    if len(name) < 12 and not has_good_prefix:
        return False
    
    return True


def generate_plan_id(provider_name: str, plan_name: str) -> str:
    """Generate a deterministic UUID-like ID from provider and plan name."""
    content = f"{provider_name.lower().strip()}|{plan_name.lower().strip()}"
    hash_bytes = hashlib.sha256(content.encode()).digest()
    hex_str = hash_bytes.hex()[:32]
    return f"{hex_str[:8]}-{hex_str[8:12]}-{hex_str[12:16]}-{hex_str[16:20]}-{hex_str[20:32]}"


def normalize_plan_data(raw_data: Dict[str, Any], provider_key: str) -> Dict[str, Any]:
    """
    Normalize scraped plan data to match the Insurance Plans table schema.
    
    Args:
        raw_data: Raw scraped data dict.
        provider_key: Provider key (e.g., "AIA", "Prudential").
    
    Returns:
        Normalized dict matching table schema.
    """
    provider_info = PROVIDERS.get(provider_key, {})
    plan_name = raw_data.get("plan_name", "Unknown Plan")
    provider_name = provider_info.get("name", provider_key)
    
    return {
        "id": generate_plan_id(provider_name, plan_name),
        "provider_name": provider_name,
        "plan_name": plan_name,
        "plan_type": raw_data.get("plan_type", "Medical"),
        "coverage_type": raw_data.get("coverage_type"),
        "annual_limit": _parse_money(raw_data.get("annual_limit")),
        "lifetime_limit": _parse_money(raw_data.get("lifetime_limit")),
        "room_board_limit": _parse_money(raw_data.get("room_board_limit")),
        "outpatient_covered": raw_data.get("outpatient_covered"),
        "maternity_covered": raw_data.get("maternity_covered"),
        "dental_covered": raw_data.get("dental_covered"),
        "optical_covered": raw_data.get("optical_covered"),
        "mental_health_covered": raw_data.get("mental_health_covered"),
        "covered_conditions": raw_data.get("covered_conditions"),
        "excluded_conditions": raw_data.get("excluded_conditions"),
        "panel_hospitals": raw_data.get("panel_hospitals"),
        "monthly_premium_min": _parse_money(raw_data.get("monthly_premium_min")),
        "monthly_premium_max": _parse_money(raw_data.get("monthly_premium_max")),
        "deductible": _parse_money(raw_data.get("deductible")),
        "co_payment_percentage": _parse_percentage(raw_data.get("co_payment_percentage")),
        "min_age": _parse_int(raw_data.get("min_age")),
        "max_age": _parse_int(raw_data.get("max_age")),
        "claim_process": raw_data.get("claim_process"),
        "contact_phone": provider_info.get("contact_phone"),
        "website": raw_data.get("website") or provider_info.get("website"),
        "is_active": True,
    }


def _parse_money(value: Any) -> Optional[float]:
    """Parse monetary value from various formats."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        # Remove currency symbols, commas, spaces
        cleaned = re.sub(r"[RM$,\s]", "", value, flags=re.IGNORECASE)
        # Handle "million" suffix
        if "million" in value.lower():
            cleaned = re.sub(r"[^0-9.]", "", cleaned)
            try:
                return float(cleaned) * 1_000_000
            except ValueError:
                pass
        try:
            return float(cleaned)
        except ValueError:
            pass
    return None


def _parse_percentage(value: Any) -> Optional[float]:
    """Parse percentage value."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        match = re.search(r"(\d+(?:\.\d+)?)", value)
        if match:
            return float(match.group(1))
    return None


def _parse_int(value: Any) -> Optional[int]:
    """Parse integer value."""
    if value is None:
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str):
        match = re.search(r"(\d+)", value)
        if match:
            return int(match.group(1))
    return None


class InsuranceScraper:
    """Scraper for Malaysian insurance company websites."""

    def __init__(self, headless: bool = True):
        """
        Initialize the scraper.
        
        Args:
            headless: Run browser in headless mode (default True).
        """
        self.headless = headless
        self._browser: Optional[Browser] = None
        self._playwright = None

    async def __aenter__(self):
        """Async context manager entry."""
        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(
            headless=self.headless,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
                "--no-sandbox",
                "--disable-gpu",
            ],
        )
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()

    async def _random_delay(self, min_sec: float = 1.0, max_sec: float = 3.0):
        """Add random delay to simulate human behavior."""
        delay = random.uniform(min_sec, max_sec)
        await asyncio.sleep(delay)

    async def _create_page(self) -> Tuple[Page, Any]:
        """Create a new browser page with random user agent."""
        context = await self._browser.new_context(
            user_agent=random.choice(USER_AGENTS),
            viewport={"width": 1280, "height": 900},
            locale="en-MY",
        )
        page = await context.new_page()
        return page, context

    async def _safe_get_text(self, page: Page, selector: str) -> Optional[str]:
        """Safely get text from an element."""
        try:
            el = await page.query_selector(selector)
            if el:
                text = await el.inner_text()
                return text.strip() if text else None
        except Exception:
            pass
        return None

    async def _safe_get_all_text(self, page: Page, selector: str) -> List[str]:
        """Safely get text from all matching elements."""
        results = []
        try:
            elements = await page.query_selector_all(selector)
            for el in elements:
                text = await el.inner_text()
                if text and text.strip():
                    results.append(text.strip())
        except Exception:
            pass
        return results

    async def _safe_get_attribute(self, page: Page, selector: str, attr: str) -> Optional[str]:
        """Safely get attribute from an element."""
        try:
            el = await page.query_selector(selector)
            if el:
                return await el.get_attribute(attr)
        except Exception:
            pass
        return None

    async def _download_pdf(self, page: Page, pdf_url: str) -> Optional[bytes]:
        """Download a PDF file."""
        try:
            response = await page.request.get(pdf_url)
            if response.ok:
                return await response.body()
        except Exception as e:
            logger.warning(f"Failed to download PDF {pdf_url}: {e}")
        return None

    def _parse_pdf_text(self, pdf_bytes: bytes) -> str:
        """Parse text content from PDF bytes."""
        try:
            import pdfplumber
            
            with io.BytesIO(pdf_bytes) as pdf_file:
                with pdfplumber.open(pdf_file) as pdf:
                    text_parts = []
                    for page in pdf.pages:
                        text = page.extract_text()
                        if text:
                            text_parts.append(text)
                    return "\n".join(text_parts)
        except Exception as e:
            logger.warning(f"Failed to parse PDF: {e}")
            return ""

    def _extract_coverage_from_text(self, text: str) -> Dict[str, Any]:
        """Extract coverage information from text content."""
        text_lower = text.lower()
        
        coverage = {
            "outpatient_covered": None,
            "maternity_covered": None,
            "dental_covered": None,
            "optical_covered": None,
            "mental_health_covered": None,
        }
        
        # Check for coverage keywords
        if any(kw in text_lower for kw in ["outpatient", "out-patient", "clinic visit"]):
            coverage["outpatient_covered"] = "not covered" not in text_lower or "outpatient" in text_lower
        
        if any(kw in text_lower for kw in ["maternity", "pregnancy", "childbirth"]):
            coverage["maternity_covered"] = True
        
        if any(kw in text_lower for kw in ["dental", "teeth", "orthodontic"]):
            coverage["dental_covered"] = True
        
        if any(kw in text_lower for kw in ["optical", "eye", "vision", "spectacles"]):
            coverage["optical_covered"] = True
        
        if any(kw in text_lower for kw in ["mental health", "psychiatric", "psychology"]):
            coverage["mental_health_covered"] = True
        
        return coverage

    def _extract_limits_from_text(self, text: str) -> Dict[str, Any]:
        """Extract limit amounts from text content."""
        limits = {
            "annual_limit": None,
            "lifetime_limit": None,
            "room_board_limit": None,
        }
        
        # Common patterns for limits
        annual_patterns = [
            r"annual\s+limit[:\s]+(?:rm\s*)?([0-9,.]+(?:\s*million)?)",
            r"yearly\s+limit[:\s]+(?:rm\s*)?([0-9,.]+(?:\s*million)?)",
            r"per\s+year[:\s]+(?:rm\s*)?([0-9,.]+(?:\s*million)?)",
        ]
        
        lifetime_patterns = [
            r"lifetime\s+limit[:\s]+(?:rm\s*)?([0-9,.]+(?:\s*million)?)",
            r"overall\s+limit[:\s]+(?:rm\s*)?([0-9,.]+(?:\s*million)?)",
        ]
        
        room_patterns = [
            r"room\s*(?:&|and)?\s*board[:\s]+(?:rm\s*)?([0-9,.]+)",
            r"daily\s+room[:\s]+(?:rm\s*)?([0-9,.]+)",
        ]
        
        text_lower = text.lower()
        
        for pattern in annual_patterns:
            match = re.search(pattern, text_lower)
            if match:
                limits["annual_limit"] = match.group(1)
                break
        
        for pattern in lifetime_patterns:
            match = re.search(pattern, text_lower)
            if match:
                limits["lifetime_limit"] = match.group(1)
                break
        
        for pattern in room_patterns:
            match = re.search(pattern, text_lower)
            if match:
                limits["room_board_limit"] = match.group(1)
                break
        
        return limits

    # ========== Provider-specific scrapers ==========

    async def _extract_product_links(self, page: Page, base_url: str) -> List[str]:
        """Extract product page links from a listing page."""
        links = []
        selectors = [
            "a[href*='product']",
            "a[href*='health']",
            "a[href*='medical']",
            ".product-card a",
            ".product-item a",
            "article a",
        ]
        
        for selector in selectors:
            try:
                elements = await page.query_selector_all(selector)
                for el in elements:
                    href = await el.get_attribute("href")
                    if href:
                        if not href.startswith("http"):
                            href = base_url + href if href.startswith("/") else base_url + "/" + href
                        if href not in links:
                            links.append(href)
            except Exception:
                continue
        
        return links[:15]  # Limit to avoid too many requests

    async def scrape_aia(self) -> List[Dict[str, Any]]:
        """Scrape AIA Malaysia health insurance products."""
        provider_key = "AIA"
        config = PROVIDERS[provider_key]
        plans = []
        seen_names = set()
        
        logger.info(f"Scraping {config['name']} products from website...")
        
        page, context = await self._create_page()
        try:
            await page.goto(config["products_url"], wait_until="domcontentloaded", timeout=30000)
            await self._random_delay(2, 4)
            
            # Multiple selector strategies to find product names
            selectors = [
                # Product cards and titles
                ".product-card h2", ".product-card h3", ".product-card .title",
                ".product-item h2", ".product-item h3", ".product-item .title",
                "article h2", "article h3",
                # Links with health/medical content
                "a[href*='health'] span", "a[href*='medical'] span",
                # Generic product name patterns
                "[class*='product'] h2", "[class*='product'] h3",
                "h2.title", "h3.title",
                # Grid/list items
                ".grid-item h3", ".list-item h3",
            ]
            
            for selector in selectors:
                names = await self._safe_get_all_text(page, selector)
                for name in names:
                    name = name.strip()
                    if is_valid_plan_name(name) and name.lower() not in seen_names:
                        seen_names.add(name.lower())
                        plan_data = {
                            "plan_name": name,
                            "plan_type": "Medical",
                            "coverage_type": "Individual",
                            "website": config["products_url"],
                        }
                        plans.append(normalize_plan_data(plan_data, provider_key))
            
            # Also search for AIA-specific product patterns in page content
            page_content = await page.content()
            aia_patterns = [
                r"A-(?:Plus|Life)\s+[A-Za-z]+(?:\s+[A-Za-z]+)?",
                r"AIA\s+(?:Medical|Health|Critical|Voluntary)[A-Za-z\s]*",
            ]
            
            for pattern in aia_patterns:
                matches = re.findall(pattern, page_content)
                for match in matches:
                    name = match.strip()
                    if is_valid_plan_name(name) and name.lower() not in seen_names:
                        seen_names.add(name.lower())
                        plan_data = {
                            "plan_name": name,
                            "plan_type": "Medical",
                            "coverage_type": "Individual",
                            "website": config["products_url"],
                        }
                        plans.append(normalize_plan_data(plan_data, provider_key))
            
            # Try to scrape individual product pages for more details
            product_links = await self._extract_product_links(page, config["base_url"])
            for link in product_links[:5]:  # Limit to first 5 product pages
                await self._random_delay(1, 2)
                try:
                    await page.goto(link, wait_until="domcontentloaded", timeout=30000)
                    await self._random_delay(1, 2)
                    
                    # Get product name from h1
                    h1_text = await self._safe_get_text(page, "h1")
                    if h1_text and is_valid_plan_name(h1_text) and h1_text.lower() not in seen_names:
                        seen_names.add(h1_text.lower())
                        
                        # Extract additional details
                        page_text = await page.content()
                        coverage = self._extract_coverage_from_text(page_text)
                        limits = self._extract_limits_from_text(page_text)
                        
                        plan_data = {
                            "plan_name": h1_text,
                            "plan_type": "Medical",
                            "coverage_type": "Individual",
                            "website": link,
                            **coverage,
                            **limits,
                        }
                        plans.append(normalize_plan_data(plan_data, provider_key))
                except Exception as e:
                    logger.debug(f"Failed to scrape product page {link}: {e}")
                    continue
                    
        except Exception as e:
            logger.error(f"Failed to scrape AIA: {e}")
        finally:
            await page.close()
            await context.close()
        
        logger.info(f"Scraped {len(plans)} plans from {config['name']}")
        return plans

    async def scrape_prudential(self) -> List[Dict[str, Any]]:
        """Scrape Prudential BSN health insurance products."""
        provider_key = "Prudential"
        config = PROVIDERS[provider_key]
        plans = []
        seen_names = set()
        
        logger.info(f"Scraping {config['name']} products from website...")
        
        page, context = await self._create_page()
        try:
            await page.goto(config["products_url"], wait_until="domcontentloaded", timeout=30000)
            await self._random_delay(2, 4)
            
            # Multiple selector strategies
            selectors = [
                ".product-card h2", ".product-card h3", ".product-card .title",
                ".product-item h2", ".product-item h3",
                "article h2", "article h3",
                "[class*='product'] h2", "[class*='product'] h3",
                ".card h3", ".card h2", ".card-title",
            ]
            
            for selector in selectors:
                names = await self._safe_get_all_text(page, selector)
                for name in names:
                    name = name.strip()
                    if is_valid_plan_name(name) and name.lower() not in seen_names:
                        seen_names.add(name.lower())
                        plan_data = {
                            "plan_name": name,
                            "plan_type": "Medical",
                            "coverage_type": "Individual",
                            "website": config["products_url"],
                        }
                        plans.append(normalize_plan_data(plan_data, provider_key))
            
            # Search for PRU-prefixed products in page content
            page_content = await page.content()
            pru_patterns = [
                r"PRU[A-Z][a-zA-Z]+(?:\s+[A-Z][a-z]+)?(?:\s+[A-Z][a-z]+)?",
                r"Prudential\s+(?:BSN\s+)?[A-Z][a-zA-Z\s]+",
            ]
            
            for pattern in pru_patterns:
                matches = re.findall(pattern, page_content)
                for match in matches:
                    name = match.strip()
                    # Filter out common false positives
                    if "Prudential plc" in name or "Prudential BSN Takaful" in name:
                        continue
                    if is_valid_plan_name(name) and name.lower() not in seen_names:
                        seen_names.add(name.lower())
                        plan_data = {
                            "plan_name": name,
                            "plan_type": "Medical",
                            "coverage_type": "Individual",
                            "website": config["products_url"],
                        }
                        plans.append(normalize_plan_data(plan_data, provider_key))
            
            # Try to scrape individual product pages
            product_links = await self._extract_product_links(page, config["base_url"])
            for link in product_links[:5]:
                await self._random_delay(1, 2)
                try:
                    await page.goto(link, wait_until="domcontentloaded", timeout=30000)
                    await self._random_delay(1, 2)
                    
                    h1_text = await self._safe_get_text(page, "h1")
                    if h1_text and is_valid_plan_name(h1_text) and h1_text.lower() not in seen_names:
                        seen_names.add(h1_text.lower())
                        
                        page_text = await page.content()
                        coverage = self._extract_coverage_from_text(page_text)
                        limits = self._extract_limits_from_text(page_text)
                        
                        plan_data = {
                            "plan_name": h1_text,
                            "plan_type": "Medical",
                            "coverage_type": "Individual",
                            "website": link,
                            **coverage,
                            **limits,
                        }
                        plans.append(normalize_plan_data(plan_data, provider_key))
                except Exception as e:
                    logger.debug(f"Failed to scrape product page {link}: {e}")
                    continue
                    
        except Exception as e:
            logger.error(f"Failed to scrape Prudential: {e}")
        finally:
            await page.close()
            await context.close()
        
        logger.info(f"Scraped {len(plans)} plans from {config['name']}")
        return plans

    async def scrape_allianz(self) -> List[Dict[str, Any]]:
        """Scrape Allianz Malaysia health insurance products."""
        provider_key = "Allianz"
        config = PROVIDERS[provider_key]
        plans = []
        seen_names = set()
        
        logger.info(f"Scraping {config['name']} products from website...")
        
        page, context = await self._create_page()
        try:
            await page.goto(config["products_url"], wait_until="domcontentloaded", timeout=30000)
            await self._random_delay(2, 4)
            
            # Multiple selector strategies
            selectors = [
                ".product-card h2", ".product-card h3", ".product-card .title",
                ".product-item h2", ".product-item h3",
                "article h2", "article h3",
                "[class*='product'] h2", "[class*='product'] h3",
                ".card h3", ".card h2", ".card-title",
                "[data-product] h3", "[data-product] h2",
            ]
            
            for selector in selectors:
                names = await self._safe_get_all_text(page, selector)
                for name in names:
                    name = name.strip()
                    if is_valid_plan_name(name) and name.lower() not in seen_names:
                        seen_names.add(name.lower())
                        plan_data = {
                            "plan_name": name,
                            "plan_type": "Medical",
                            "coverage_type": "Individual",
                            "website": config["products_url"],
                        }
                        plans.append(normalize_plan_data(plan_data, provider_key))
            
            # Search for Allianz-specific products in page content
            page_content = await page.content()
            allianz_patterns = [
                r"Allianz\s+(?:Care|Health|Medi|Criti)[A-Za-z]*(?:\s+[A-Za-z]+)?",
                r"MediSafe\s*(?:Infinite|Plus|Basic)?",
                r"Hospital\s*(?:&|and)?\s*Surgical(?:\s+[A-Za-z]+)?",
            ]
            
            for pattern in allianz_patterns:
                matches = re.findall(pattern, page_content, re.IGNORECASE)
                for match in matches:
                    name = match.strip()
                    # Filter out false positives
                    if "Allianz Malaysia" in name or "Allianz Customer" in name:
                        continue
                    if is_valid_plan_name(name) and name.lower() not in seen_names:
                        seen_names.add(name.lower())
                        plan_data = {
                            "plan_name": name,
                            "plan_type": "Medical",
                            "coverage_type": "Individual",
                            "website": config["products_url"],
                        }
                        plans.append(normalize_plan_data(plan_data, provider_key))
            
            # Try to scrape individual product pages
            product_links = await self._extract_product_links(page, config["base_url"])
            for link in product_links[:5]:
                await self._random_delay(1, 2)
                try:
                    await page.goto(link, wait_until="domcontentloaded", timeout=30000)
                    await self._random_delay(1, 2)
                    
                    h1_text = await self._safe_get_text(page, "h1")
                    if h1_text and is_valid_plan_name(h1_text) and h1_text.lower() not in seen_names:
                        seen_names.add(h1_text.lower())
                        
                        page_text = await page.content()
                        coverage = self._extract_coverage_from_text(page_text)
                        limits = self._extract_limits_from_text(page_text)
                        
                        plan_data = {
                            "plan_name": h1_text,
                            "plan_type": "Medical",
                            "coverage_type": "Individual",
                            "website": link,
                            **coverage,
                            **limits,
                        }
                        plans.append(normalize_plan_data(plan_data, provider_key))
                except Exception as e:
                    logger.debug(f"Failed to scrape product page {link}: {e}")
                    continue
                    
        except Exception as e:
            logger.error(f"Failed to scrape Allianz: {e}")
        finally:
            await page.close()
            await context.close()
        
        logger.info(f"Scraped {len(plans)} plans from {config['name']}")
        return plans

    async def scrape_great_eastern(self) -> List[Dict[str, Any]]:
        """Scrape Great Eastern health insurance products."""
        provider_key = "GreatEastern"
        config = PROVIDERS[provider_key]
        plans = []
        seen_names = set()
        
        logger.info(f"Scraping {config['name']} products from website...")
        
        page, context = await self._create_page()
        try:
            await page.goto(config["products_url"], wait_until="domcontentloaded", timeout=30000)
            await self._random_delay(2, 4)
            
            # Multiple selector strategies
            selectors = [
                ".product-card h2", ".product-card h3", ".product-card .title",
                ".product-item h2", ".product-item h3",
                "article h2", "article h3",
                "[class*='product'] h2", "[class*='product'] h3",
                ".card h3", ".card h2", ".card-title",
            ]
            
            for selector in selectors:
                names = await self._safe_get_all_text(page, selector)
                for name in names:
                    name = name.strip()
                    if is_valid_plan_name(name) and name.lower() not in seen_names:
                        seen_names.add(name.lower())
                        plan_data = {
                            "plan_name": name,
                            "plan_type": "Medical",
                            "coverage_type": "Individual",
                            "website": config["products_url"],
                        }
                        plans.append(normalize_plan_data(plan_data, provider_key))
            
            # Search for Great Eastern specific products in page content
            page_content = await page.content()
            ge_patterns = [
                r"GREAT\s+(?:HealthCare|MediCash|Critical|Total|Life)[A-Za-z]*(?:\s+[A-Za-z]+)?",
                r"Supreme\s+Health(?:\s+[A-Za-z]+)?",
                r"SmartMedic(?:\s+[A-Za-z]+)?",
                r"Great\s+(?:Care|Shield|Protect)[A-Za-z]*",
            ]
            
            for pattern in ge_patterns:
                matches = re.findall(pattern, page_content, re.IGNORECASE)
                for match in matches:
                    name = match.strip()
                    # Filter out false positives
                    if "Great Eastern" in name and len(name) < 20:
                        continue
                    if is_valid_plan_name(name) and name.lower() not in seen_names:
                        seen_names.add(name.lower())
                        plan_data = {
                            "plan_name": name,
                            "plan_type": "Medical",
                            "coverage_type": "Individual",
                            "website": config["products_url"],
                        }
                        plans.append(normalize_plan_data(plan_data, provider_key))
            
            # Try to scrape individual product pages
            product_links = await self._extract_product_links(page, config["base_url"])
            for link in product_links[:5]:
                await self._random_delay(1, 2)
                try:
                    await page.goto(link, wait_until="domcontentloaded", timeout=30000)
                    await self._random_delay(1, 2)
                    
                    h1_text = await self._safe_get_text(page, "h1")
                    if h1_text and is_valid_plan_name(h1_text) and h1_text.lower() not in seen_names:
                        seen_names.add(h1_text.lower())
                        
                        page_text = await page.content()
                        coverage = self._extract_coverage_from_text(page_text)
                        limits = self._extract_limits_from_text(page_text)
                        
                        plan_data = {
                            "plan_name": h1_text,
                            "plan_type": "Medical",
                            "coverage_type": "Individual",
                            "website": link,
                            **coverage,
                            **limits,
                        }
                        plans.append(normalize_plan_data(plan_data, provider_key))
                except Exception as e:
                    logger.debug(f"Failed to scrape product page {link}: {e}")
                    continue
                    
        except Exception as e:
            logger.error(f"Failed to scrape Great Eastern: {e}")
        finally:
            await page.close()
            await context.close()
        
        logger.info(f"Scraped {len(plans)} plans from {config['name']}")
        return plans

    async def scrape_etiqa(self) -> List[Dict[str, Any]]:
        """Scrape Etiqa health insurance products."""
        provider_key = "Etiqa"
        config = PROVIDERS[provider_key]
        plans = []
        seen_names = set()
        
        logger.info(f"Scraping {config['name']} products from website...")
        
        page, context = await self._create_page()
        try:
            await page.goto(config["products_url"], wait_until="domcontentloaded", timeout=30000)
            await self._random_delay(2, 4)
            
            # Multiple selector strategies
            selectors = [
                ".product-card h2", ".product-card h3", ".product-card .title",
                ".product-item h2", ".product-item h3",
                "article h2", "article h3",
                "[class*='product'] h2", "[class*='product'] h3",
                ".card h3", ".card h2", ".card-title",
            ]
            
            for selector in selectors:
                names = await self._safe_get_all_text(page, selector)
                for name in names:
                    name = name.strip()
                    if is_valid_plan_name(name) and name.lower() not in seen_names:
                        seen_names.add(name.lower())
                        plan_data = {
                            "plan_name": name,
                            "plan_type": "Medical",
                            "coverage_type": "Individual",
                            "website": config["products_url"],
                        }
                        plans.append(normalize_plan_data(plan_data, provider_key))
            
            # Search for Etiqa specific products in page content
            page_content = await page.content()
            etiqa_patterns = [
                r"Medical\s+EZ(?:\s+[A-Za-z]+)?",
                r"Takaful\s+Medi[A-Za-z]+(?:\s+[A-Za-z]+)?",
                r"Etiqa\s+(?:Health|Family|Critical|Medi)[A-Za-z]*(?:\s+[A-Za-z]+)?",
                r"i-Medik(?:\s+[A-Za-z]+)?",
            ]
            
            for pattern in etiqa_patterns:
                matches = re.findall(pattern, page_content, re.IGNORECASE)
                for match in matches:
                    name = match.strip()
                    # Filter out false positives
                    if "Etiqa Insurance" in name or "Etiqa today" in name:
                        continue
                    if is_valid_plan_name(name) and name.lower() not in seen_names:
                        seen_names.add(name.lower())
                        plan_data = {
                            "plan_name": name,
                            "plan_type": "Medical",
                            "coverage_type": "Individual",
                            "website": config["products_url"],
                        }
                        plans.append(normalize_plan_data(plan_data, provider_key))
            
            # Try to scrape individual product pages
            product_links = await self._extract_product_links(page, config["base_url"])
            for link in product_links[:5]:
                await self._random_delay(1, 2)
                try:
                    await page.goto(link, wait_until="domcontentloaded", timeout=30000)
                    await self._random_delay(1, 2)
                    
                    h1_text = await self._safe_get_text(page, "h1")
                    if h1_text and is_valid_plan_name(h1_text) and h1_text.lower() not in seen_names:
                        seen_names.add(h1_text.lower())
                        
                        page_text = await page.content()
                        coverage = self._extract_coverage_from_text(page_text)
                        limits = self._extract_limits_from_text(page_text)
                        
                        plan_data = {
                            "plan_name": h1_text,
                            "plan_type": "Medical",
                            "coverage_type": "Individual",
                            "website": link,
                            **coverage,
                            **limits,
                        }
                        plans.append(normalize_plan_data(plan_data, provider_key))
                except Exception as e:
                    logger.debug(f"Failed to scrape product page {link}: {e}")
                    continue
                    
        except Exception as e:
            logger.error(f"Failed to scrape Etiqa: {e}")
        finally:
            await page.close()
            await context.close()
        
        logger.info(f"Scraped {len(plans)} plans from {config['name']}")
        return plans

    async def scrape_all_providers(self) -> Dict[str, List[Dict[str, Any]]]:
        """
        Scrape all insurance providers.
        
        Returns:
            Dict mapping provider key to list of normalized plan dicts.
        """
        results = {}
        
        scraper_methods = [
            ("AIA", self.scrape_aia),
            ("Prudential", self.scrape_prudential),
            ("Allianz", self.scrape_allianz),
            ("GreatEastern", self.scrape_great_eastern),
            ("Etiqa", self.scrape_etiqa),
        ]
        
        for provider_key, scraper in scraper_methods:
            try:
                plans = await scraper()
                results[provider_key] = plans
                await self._random_delay(3, 5)  # Delay between providers
            except Exception as e:
                logger.error(f"Failed to scrape {provider_key}: {e}")
                results[provider_key] = []
        
        return results


async def scrape_insurance_plans(headless: bool = True) -> List[Dict[str, Any]]:
    """
    Scrape insurance plans from all providers.
    
    Args:
        headless: Run browser in headless mode.
    
    Returns:
        List of normalized plan dicts ready for database insertion.
    """
    all_plans = []
    
    async with InsuranceScraper(headless=headless) as scraper:
        results = await scraper.scrape_all_providers()
        
        for provider_key, plans in results.items():
            all_plans.extend(plans)
            logger.info(f"{provider_key}: {len(plans)} plans")
    
    logger.info(f"Total plans scraped: {len(all_plans)}")
    return all_plans


def scrape_insurance_plans_sync(headless: bool = True) -> List[Dict[str, Any]]:
    """
    Synchronous wrapper for scraping insurance plans.
    
    Args:
        headless: Run browser in headless mode.
    
    Returns:
        List of normalized plan dicts.
    """
    return asyncio.run(scrape_insurance_plans(headless=headless))

